﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleComponents
{
    public interface Component
    {
        void Compute();
    }
}
